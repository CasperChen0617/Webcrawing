import os

os.system('cd ~')
os.system('cd Users')
os.system('cd Lin')
os.system('cd AppData')
os.system('cd Local')
os.system('cd Programs')
os.system('cd Python')
os.system('cd Scripts')

os.system('python get-pip.py')


os.system('pip list')

#for vision 3.x.x
os.system('pip install -vvv requests')
os.system('pip install -vvv pandas')
os.system('pip install -vvv lxml')
os.system('pip install -vvv html5lib')
os.system('pip install -vvv describe')
os.system('pip install -vvv matplotlib')
os.system('pip install -vvv sklearn')
os.system('pip install -vvv jupyter')






